# ICFA Database Design Documentation

## Overview

This document outlines the database structure and planning for the Intelligent Customer Feedback Analyzer (ICFA) system. The database is designed to support a multi-user environment with session tracking, result persistence, and data isolation.

## Current Implementation Status

###  Implemented Components

1. **Database Schema** - Complete SQLite schema defined
2. **User Authentication** - In-memory storage (to be migrated to DB)
3. **Analysis Routes** - Feedback and Churn analysis endpoints
4. **Frontend Interface** - Streamlit-based dashboard with file upload

###  Pending Integration

1. **Database Integration** - Auth and analysis routes need DB integration
2. **Session Persistence** - Results currently not persisted
3. **User History** - No session history in dashboard

## Database Schema Design

### Core Tables

#### 1. users
**Purpose**: Store user account information and authentication data
**Key Features**:
- Unique username and email constraints
- Password hash storage (currently plain text in auth.py)
- Account status tracking (active/inactive)
- Login timestamp tracking

**Fields**:
- `id` (Primary Key, Auto-increment)
- `username` (Unique, Not Null)
- `email` (Unique, Not Null)
- `password_hash` (Not Null)
- `created_at` (Timestamp, Default Current)
- `last_login` (Timestamp)
- `is_active` (Boolean, Default True)

#### 2. analysis_sessions
**Purpose**: Track analysis sessions per user with metadata
**Key Features**:
- Links to user accounts
- Session type tracking (sentiment/churn)
- File upload metadata
- Session status tracking
- JSON storage for flexible metadata

**Fields**:
- `id` (Primary Key, Auto-increment)
- `user_id` (Foreign Key to users.id)
- `session_type` (Text: 'sentiment' or 'churn')
- `file_name` (Text)
- `file_size` (Integer)
- `upload_time` (Timestamp, Default Current)
- `status` (Text: 'processing', 'completed', 'failed')
- `result_data` (Text - JSON stored as TEXT)
- `metadata` (Text - JSON stored as TEXT)

#### 3. analysis_results
**Purpose**: Store detailed results for each uploaded file
**Key Features**:
- Links to analysis sessions
- Individual record storage
- JSON result storage for flexibility
- Timestamp tracking

**Fields**:
- `id` (Primary Key, Auto-increment)
- `session_id` (Foreign Key to analysis_sessions.id)
- `record_id` (Text - unique identifier for each record)
- `result_data` (Text - JSON stored as TEXT)
- `created_at` (Timestamp, Default Current)

## Data Flow Architecture

### User Authentication Flow
```
1. User registers/login → Auth endpoint
2. Credentials validated → JWT token generated
3. Token stored in session → Dashboard access
4. Future requests → Token validated
```

### Analysis Session Flow
```
1. User uploads file → Analysis endpoint
2. File processed → Results generated
3. Session created → Results stored
4. Results returned → Dashboard display
```

### Data Isolation Strategy
- All data queries filtered by `user_id`
- Session history per user
- No cross-user data access
- Secure session management

## Integration Points

### Backend Integration Required

1. **auth.py** → **users table**
   - Replace in-memory USERS_DB with database queries
   - Implement password hashing (currently plain text)
   - Add user registration/login with DB persistence

2. **feedback.py** → **analysis_sessions + analysis_results**
   - Create session record on file upload
   - Store analysis results in analysis_results table
   - Update session status and metadata

3. **churn.py** → **analysis_sessions + analysis_results**
   - Same pattern as feedback analysis
   - Store churn predictions with customer details

### Frontend Integration Required

1. **Dashboard** → **Session History**
   - Add "My History" section
   - Display past analysis sessions
   - Allow re-viewing previous results

2. **Analysis Pages** → **Session Tracking**
   - Show session status (processing/completed)
   - Display session metadata
   - Provide session management options

## Security Considerations

### Data Protection
- Password hashing (currently storing plain text)
- JWT token expiration (8 hours)
- User data isolation
- File upload validation

### Database Security
- SQLite file permissions
- Input validation and sanitization
- SQL injection prevention
- Session timeout handling

## Performance Considerations

### File Processing
- Current limit: 50 reviews for sentiment analysis
- Churn analysis: 100 predictions returned
- Consider pagination for large datasets
- Async processing for long-running analyses

### Database Optimization
- Index on user_id for fast queries
- Index on session_type for filtering
- Consider result_data size limits
- Regular cleanup of old sessions

## Future Enhancements

### Schema Extensions
1. **user_preferences** table for custom settings
2. **notifications** table for analysis completion alerts
3. **shared_sessions** table for team collaboration
4. **audit_log** table for security tracking

### Feature Enhancements
1. **Batch processing** for multiple files
2. **Scheduled analyses** for recurring reports
3. **Export functionality** for results
4. **API rate limiting** for production use

## Migration Strategy

### Phase 1: Core Integration
1. Implement database connection utilities
2. Migrate user authentication to database
3. Add session creation to analysis endpoints
4. Store basic session metadata

### Phase 2: Result Persistence
1. Implement analysis_results table storage
2. Add session status tracking
3. Update frontend to show session history
4. Add result retrieval endpoints

### Phase 3: Advanced Features
1. Implement user preferences
2. Add notification system
3. Optimize for large datasets
4. Add administrative features

## Testing Strategy

### Unit Tests
- Database connection and queries
- Authentication flow validation
- Session creation and management
- Result storage and retrieval

### Integration Tests
- End-to-end analysis workflow
- User isolation verification
- File upload and processing
- Frontend-backend communication

### Performance Tests
- Large file processing
- Concurrent user handling
- Database query optimization
- Memory usage monitoring

## Monitoring and Maintenance

### Database Monitoring
- Connection pool management
- Query performance tracking
- Storage usage monitoring
- Backup and recovery procedures

### Application Monitoring
- Analysis completion rates
- User activity tracking
- Error rate monitoring
- Performance metrics collection

This database design provides a solid foundation for the ICFA system, supporting current requirements while allowing for future growth and enhancement.